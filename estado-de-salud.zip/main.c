/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int edad, colesterol;
    float imc;
    
    
    printf("ingresar edad:");
    scanf("%d", &edad);
    printf("ingresar Colesterol:");
    scanf("%d", &colesterol);
    printf("ingresar IMC:");
    scanf("%f", &imc);
    if((edad <=18 && imc<=18.5 && imc <=24.99 && colesterol <200) || (edad>=30 && edad < 50 && imc <=18.5 && imc <= 29.9 && colesterol <=240))
    {
        printf("estado de salud aceptable");
    }
    else
    {
        printf("estas Estado de salud inaceptable");
    }

    return 0;
}