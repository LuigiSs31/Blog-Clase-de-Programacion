/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
/* autor: Luid Mario Romano Gonzalez
   Fecha: 9/3/24
   Nombre: Ciclos_For. C

*/
int main()
{
    //Zona de declaracion de variables
    // Ciclo For que recorre los numeros del 1 al 10
    
    for(int i=0;i<=100;i+=5)
    
    {
        //Cuerpo del ciclo for
        printf( "%d,", i);
    } // Fin de for

    return 0;
}