/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/* autor: Luis Mario Romano
fecha 8/27/24 */
#include <stdio.h>

int main()
{
  //Zona de declaracion de variables
 
  short signed int aNacimiento, edad ;
  printf("Escribe tu año de nacimiento:");
  scanf("%d" , &aNacimiento );//leer el año y guardarla en la variable 
  edad= (2024 - aNacimiento);
  printf ("%d", edad);

  /* signed: valores positivos y negativos, unsigned: solo valores positivos
  short: enteros mas pequeños, long: enteros mas grandes */ 

    return 0;
}
//Ejercicio:
// 1- imprimir el año de nacimiento
// 2- calcular su edad
// 3- imprimir su edad
