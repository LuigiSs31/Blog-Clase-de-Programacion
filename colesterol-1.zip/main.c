/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
// 

int main()
{
    int edad, Col;
    float IMC;
    scanf("Cual es la edad: %d",edad);
    scanf("Cual es el IMC: %d",IMC);
    if (edad<=30 && IMC>=18.5 && IMC<=24.9)
    {
        printf("El colesterol es menor a 200");
    }
    

    return 0;
}
