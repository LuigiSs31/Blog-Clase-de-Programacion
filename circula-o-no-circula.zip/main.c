/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
     // Variables
    float Aceite, PSI, Temp;
    int Frenos, Escape;
    printf("Dime tu porcentaje de aceite");
    scanf("%f", &Aceite);
    printf("Dime la presion de las llantas");
    scanf("%f", &PSI);
    printf("Dime la temperatura del motor");
    scanf("%f", &Temp);
    printf("indinque con 0 para fallas, 1 para fallas nulas\n");
    printf("¿Funcionan tus frenos?");
    scanf("%d", &Frenos);
    printf("indinque con 1 para fallas, 0 para fallas nulas\n");
    printf("¿Funciona tu escape?");
    scanf("%d", &Escape);
    
    if(Aceite>=30 && Aceite<=80 && PSI>=30 && PSI<=35 && Temp<100 && Frenos>0 && Escape<1 )
    {
      printf("Si circula");
    }
    
    else
    {
        printf("no circula");
    }


    return 0;
}