/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float sueldo, descuento;
    printf("Cual es tu Sueldo?");
    scanf("%f", &sueldo);
    if (sueldo>=1000)
    {
        printf("Tiene descuento");
        descuento=sueldo*0.87;
         printf("el descuento es  $ %.2f\n", descuento);
    }
    else  
    {
        printf("No tiene descuento");
    }
  
    

    return 0;
}